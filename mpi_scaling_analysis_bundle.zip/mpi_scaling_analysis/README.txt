MPI Scaling Analysis - Assignment 3

Files
-----
scaling_results.csv   Measured MPI results (1, 2, 4, and 8 processes).
analyze_scaling.py    Recomputes metrics and generates publication-quality plots.

Requirements
------------
Python 3 and pandas and matplotlib.

Install on Ubuntu / WSL:
    sudo apt update
    sudo apt install python3-pandas python3-matplotlib

Run from the directory containing the CSV and script:
    python3 analyze_scaling.py

Or specify paths:
    python3 analyze_scaling.py scaling_results.csv --outdir analysis_output

Outputs
-------
analysis_output/scaling_analysis.csv
analysis_output/speedup_vs_processes.png
analysis_output/efficiency_vs_processes.png
analysis_output/communication_overhead.png

Method
------
T1 is the measured MPI runtime for one MPI process.
Speedup = T1 / Tp
Parallel efficiency (%) = 100 * Speedup / p
Communication percentage = 100 * Communication_Overhead / MPI_Runtime

Important
---------
Only the four measured configurations (1, 2, 4, 8) are included.
The 16-process job remained pending and was not measured, so no result for 16
processes is fabricated. The script uses the supplied measured runtime values.
