#!/usr/bin/env python3
"""
MPI scaling analysis for Assignment 3.

Usage:
    python3 analyze_scaling.py
    python3 analyze_scaling.py scaling_results.csv
    python3 analyze_scaling.py scaling_results.csv --outdir analysis_output

The script recomputes Speedup, Parallel Efficiency, and Communication
Overhead percentage from the measured MPI runtime and communication time.
It does not invent missing process-count measurements (e.g. 16 processes).
"""
from pathlib import Path
import argparse
import pandas as pd
import matplotlib.pyplot as plt

REQUIRED = {
    "Processes", "Matrix_Size", "MPI_Runtime",
    "Compute_Time", "Communication_Overhead"
}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_file", nargs="?", default="scaling_results.csv")
    parser.add_argument("--outdir", default="analysis_output")
    args = parser.parse_args()

    csv_path = Path(args.csv_file)
    if not csv_path.exists():
        raise SystemExit(
            f"Cannot find {csv_path}. Place scaling_results.csv in the "
            "current directory or pass its path as an argument."
        )

    df = pd.read_csv(csv_path)
    missing = REQUIRED - set(df.columns)
    if missing:
        raise SystemExit(f"CSV is missing required columns: {', '.join(sorted(missing))}")

    df = df.sort_values("Processes").reset_index(drop=True)
    if df.empty or (df["Processes"] <= 0).any():
        raise SystemExit("CSV must contain at least one row with positive Processes.")
    if (df["MPI_Runtime"] <= 0).any():
        raise SystemExit("MPI_Runtime values must be positive.")

    # Use the measured one-process MPI runtime as the baseline.
    baseline_rows = df.loc[df["Processes"] == 1, "MPI_Runtime"]
    if baseline_rows.empty:
        raise SystemExit("A measured Processes=1 row is required for Speedup.")
    t1 = float(baseline_rows.iloc[0])

    df["Speedup"] = t1 / df["MPI_Runtime"]
    df["Efficiency_Percent"] = 100.0 * df["Speedup"] / df["Processes"]
    df["Communication_Percent"] = (
        100.0 * df["Communication_Overhead"] / df["MPI_Runtime"]
    )

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    # Save recomputed metrics with full precision.
    output_csv = outdir / "scaling_analysis.csv"
    df.to_csv(output_csv, index=False, float_format="%.9f")

    # Speedup plot.
    plt.figure()
    plt.plot(df["Processes"], df["Speedup"], marker="o", label="Measured speedup")
    plt.plot(df["Processes"], df["Processes"], linestyle="--", label="Ideal linear speedup")
    plt.xlabel("Number of MPI processes")
    plt.ylabel("Speedup")
    plt.title("Speedup vs. Number of MPI Processes")
    plt.xticks(df["Processes"])
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig(outdir / "speedup_vs_processes.png", dpi=300)
    plt.close()

    # Efficiency plot.
    plt.figure()
    plt.plot(df["Processes"], df["Efficiency_Percent"], marker="o")
    plt.xlabel("Number of MPI processes")
    plt.ylabel("Parallel efficiency (%)")
    plt.title("Parallel Efficiency vs. Number of MPI Processes")
    plt.xticks(df["Processes"])
    plt.ylim(bottom=0)
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(outdir / "efficiency_vs_processes.png", dpi=300)
    plt.close()

    # Communication overhead plot.
    plt.figure()
    plt.plot(df["Processes"], df["Communication_Overhead"], marker="o")
    plt.xlabel("Number of MPI processes")
    plt.ylabel("Communication overhead (seconds)")
    plt.title("Communication Overhead vs. Number of MPI Processes")
    plt.xticks(df["Processes"])
    plt.ylim(bottom=0)
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(outdir / "communication_overhead.png", dpi=300)
    plt.close()

    print(f"Baseline T1 (one MPI process): {t1:.6f} seconds")
    print(df[[
        "Processes", "MPI_Runtime", "Speedup",
        "Efficiency_Percent", "Communication_Overhead",
        "Communication_Percent"
    ]].to_string(index=False, float_format=lambda x: f"{x:.4f}"))
    print(f"\nSaved analysis CSV and three PNG plots in: {outdir.resolve()}")
    print("Only measured process counts are included; no 16-process result was added.")

if __name__ == "__main__":
    main()
